/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joption;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author gfrei
 */
public class Joption {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int resposta;
        int pergunta;
        Icon figura;
       
        JOptionPane.showMessageDialog(null, "BEM VINDO A SUA JORNADA POKEMON", "Alerta", JOptionPane.WARNING_MESSAGE, new ImageIcon("D:/img/poke1.gif"));
        
        Object[] inicio = { "Casa do Ash", "Laboratório", "PokeCenter" };
            Object selectedValue = JOptionPane.showInputDialog(null,"Para onde voce deseja ir?? ", 
                "Opcao",JOptionPane.QUESTION_MESSAGE, null,
                inicio, inicio [0]);       
               
             if(selectedValue == "Casa do Ash"){
                JOptionPane.showMessageDialog(null, "O que você veio fazer aqui de novo filho, você nao ia começar sua jornada?");
            }else if(selectedValue == "Laboratório") {
                JOptionPane.showMessageDialog(null, "Muito bem, agora vamos para as escolhas!"); 
                
                Object[] poke = { "Bulbassauro", "Squirtle", "Charmander" };
                 selectedValue = JOptionPane.showInputDialog(null,"Qual vai ser seu inicial? ", 
                "POKEMON!!!",JOptionPane.QUESTION_MESSAGE, null,
                poke, poke [0]);   
                
                
                if(selectedValue == "Squirtle"){
                    JOptionPane.showMessageDialog(null, "Seu pokemon é o SQUIRTLE!! Ele e do tipo agua!", "Alerta", JOptionPane.WARNING_MESSAGE, new ImageIcon("D:/img/squirtle.png"));
                    }else if(selectedValue == "Bulbassauro") {
                JOptionPane.showMessageDialog(null, "Seu pokemon é o BULBASSAURO!! Ele e do tipo planta!", "Alerta", JOptionPane.WARNING_MESSAGE, new ImageIcon("D:/img/bulba.png"));
                    }
            
            else if(selectedValue == "Charmander") {
                JOptionPane.showMessageDialog(null, "Seu pokemon é o CHARMANDER!! Ele e do tipo fogo!", "Alerta", JOptionPane.WARNING_MESSAGE, new ImageIcon("D:/img/char.png"));
            }
            }
                
             JOptionPane.showMessageDialog(null, "Agora voce ja pode começar sua jornada!", "Alerta", JOptionPane.WARNING_MESSAGE, new ImageIcon("D:/img/ash.png"));
             
             
        
     
       
            
                                                    
    
    }

    private static Object getToolkit() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
                            
        
                                                
}   
    
   
